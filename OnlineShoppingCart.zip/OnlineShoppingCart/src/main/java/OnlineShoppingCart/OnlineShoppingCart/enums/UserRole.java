package OnlineShoppingCart.OnlineShoppingCart.enums;

public enum UserRole {

    ADMIN,
    CUSTOMER
}
