package OnlineShoppingCart.OnlineShoppingCart.service.customer.wishlist;

import OnlineShoppingCart.OnlineShoppingCart.dto.WishListDto;

import java.util.List;

public interface WishListService {
    WishListDto addProductToWishList(WishListDto wishListDto);
    List<WishListDto> getAllByUserId(Long userId);
}
