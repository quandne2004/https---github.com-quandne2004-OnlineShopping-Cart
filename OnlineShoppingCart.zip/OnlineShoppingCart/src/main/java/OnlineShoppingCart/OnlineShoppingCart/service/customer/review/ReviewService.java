package OnlineShoppingCart.OnlineShoppingCart.service.customer.review;

import OnlineShoppingCart.OnlineShoppingCart.dto.OrderedProductResponseDto;
import OnlineShoppingCart.OnlineShoppingCart.dto.ReviewDto;

import java.io.IOException;

public interface ReviewService {
    OrderedProductResponseDto getOrderedProductsDetailsByOrderId(Long orderId);
    ReviewDto giveReview(ReviewDto reviewDto) throws IOException;
}
