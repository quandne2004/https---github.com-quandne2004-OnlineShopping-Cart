package OnlineShoppingCart.OnlineShoppingCart.controller.customer;


import OnlineShoppingCart.OnlineShoppingCart.dto.AddProductInCartDto;
import OnlineShoppingCart.OnlineShoppingCart.dto.OrderDto;
import OnlineShoppingCart.OnlineShoppingCart.dto.PlaceOrderDto;
import OnlineShoppingCart.OnlineShoppingCart.entity.Order;
import OnlineShoppingCart.OnlineShoppingCart.exception.ValidationException;
import OnlineShoppingCart.OnlineShoppingCart.service.customer.cart.CartService;
import lombok.RequiredArgsConstructor;
import org.aspectj.weaver.ast.Or;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/customer")
@RequiredArgsConstructor
public class CartController {

    private  final CartService cartService;


    @PostMapping("/cart")
    public ResponseEntity<?> addProductToCart(@RequestBody AddProductInCartDto addProductInCartDto){
        return cartService.addProductToCart(addProductInCartDto);
    }


    @GetMapping("/cart/{userId}")
    public ResponseEntity<?> getCartById(@PathVariable Long userId){
        OrderDto orderDto = cartService.getCardByUserId(userId);
        return ResponseEntity.status(HttpStatus.OK).body(orderDto);
    }


    @GetMapping("/coupon/{userId}/{code}")
    public ResponseEntity<?> applyCoupon(@PathVariable Long userId,@PathVariable String code){
        try {
            OrderDto orderDto = cartService.applyCoupon(userId,code);
            return ResponseEntity.ok(orderDto);
        }catch (ValidationException e ){
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        }
    }

    @PostMapping("/addition")
    public ResponseEntity<OrderDto> increaseProduct(@RequestBody AddProductInCartDto addProductInCartDto){
        return ResponseEntity.status(HttpStatus.CREATED).body(cartService.increaseProduct(addProductInCartDto));
    }

    @PostMapping("/deduction")
    public ResponseEntity<OrderDto> decreaseProduct(@RequestBody AddProductInCartDto addProductInCartDto){
        return ResponseEntity.status(HttpStatus.CREATED).body(cartService.decreaseProduct(addProductInCartDto));
    }

    @PostMapping("/placeOrder")
    public ResponseEntity<OrderDto> placeOrder(@RequestBody PlaceOrderDto placeOrderDto){
        return ResponseEntity.status(HttpStatus.CREATED).body(cartService.placeOrder(placeOrderDto));
    }


    @GetMapping("/myOrders/{userId}")
    public ResponseEntity<List<OrderDto>> getMyPlaceOrders(@PathVariable Long userId){
        return ResponseEntity.ok(cartService.getAllPlacedOrders(userId));
    }

}
