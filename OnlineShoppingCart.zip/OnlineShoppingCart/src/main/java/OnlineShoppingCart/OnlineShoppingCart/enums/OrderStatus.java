package OnlineShoppingCart.OnlineShoppingCart.enums;

public enum OrderStatus {
    PENDING,
    PLACED,
    SHIPPED,
    DELIVERED
}
