package OnlineShoppingCart.OnlineShoppingCart.controller.customer;


import OnlineShoppingCart.OnlineShoppingCart.dto.ProductDetailDto;
import OnlineShoppingCart.OnlineShoppingCart.dto.ProductDto;
import OnlineShoppingCart.OnlineShoppingCart.service.customer.CustomerProductService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/customer")
@RequiredArgsConstructor
public class CustomerProductController {

    private final CustomerProductService productService;

    @GetMapping("/products")
    public ResponseEntity<List<ProductDto>> getAllProduct(){
        List<ProductDto> productDtos = productService.getAllProduct();
        return ResponseEntity.ok(productDtos);
    }


    @GetMapping("/search/{name}")
    public ResponseEntity<List<ProductDto>> getAllProductByName(@PathVariable String name){
        List<ProductDto> productDtos = productService.getAllProductByName(name);
        return ResponseEntity.ok(productDtos);
    }


    @GetMapping("/getProductById/{productId}")
    public ResponseEntity<ProductDetailDto> getProductDetailById(@PathVariable Long productId){
        ProductDetailDto productDetailDto =productService.getProductDetailById(productId);
        if (productDetailDto == null){
            return ResponseEntity.notFound().build();
        }else {
            return ResponseEntity.ok(productDetailDto);
        }
    }


}
