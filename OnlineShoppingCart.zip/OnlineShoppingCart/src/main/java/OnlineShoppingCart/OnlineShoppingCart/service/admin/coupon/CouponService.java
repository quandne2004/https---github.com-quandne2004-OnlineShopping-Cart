package OnlineShoppingCart.OnlineShoppingCart.service.admin.coupon;

import OnlineShoppingCart.OnlineShoppingCart.entity.Coupon;

import java.util.List;

public interface CouponService {
    Coupon createCoupon(Coupon coupon);
    List<Coupon> getAllCoupon();
}
