package OnlineShoppingCart.OnlineShoppingCart.service.admin.order;

import OnlineShoppingCart.OnlineShoppingCart.dto.AnalyticsResponse;
import OnlineShoppingCart.OnlineShoppingCart.dto.OrderDto;

import java.util.List;

public interface OrderService {
    List<OrderDto> getAllPlacedOrdered();
    OrderDto changeOrderStatus(Long orderId,String status);
    AnalyticsResponse calculateAnalytics();
}
