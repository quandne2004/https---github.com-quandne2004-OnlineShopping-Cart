package OnlineShoppingCart.OnlineShoppingCart.service.customer;

import OnlineShoppingCart.OnlineShoppingCart.dto.ProductDetailDto;
import OnlineShoppingCart.OnlineShoppingCart.dto.ProductDto;

import java.util.List;

public interface CustomerProductService {
    List<ProductDto> getAllProduct();
    List<ProductDto> getAllProductByName(String name);
    ProductDetailDto getProductDetailById(Long productId);
}
