package OnlineShoppingCart.OnlineShoppingCart.service.admin.FAQ;

import OnlineShoppingCart.OnlineShoppingCart.dto.FAQDto;

public interface FAQService {

    FAQDto postFAQ(Long productId, FAQDto faqDto);
}
