package OnlineShoppingCart.OnlineShoppingCart.controller.admin;

import OnlineShoppingCart.OnlineShoppingCart.entity.Coupon;
import OnlineShoppingCart.OnlineShoppingCart.exception.ValidationException;
import OnlineShoppingCart.OnlineShoppingCart.service.admin.coupon.CouponService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/admin")
public class CouponController {
    private final CouponService couponService;


    @PostMapping("/coupons")
    public ResponseEntity<?> createCoupon(@RequestBody Coupon coupon){
        try{
            Coupon createdCoupon = couponService.createCoupon(coupon);
            return ResponseEntity.ok(createdCoupon);
        }catch (ValidationException e){
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        }
    }


    @GetMapping("/allCoupons")
    public ResponseEntity<List<Coupon>> getAllCoupon(){
        return ResponseEntity.ok(couponService.getAllCoupon());
    }
}
