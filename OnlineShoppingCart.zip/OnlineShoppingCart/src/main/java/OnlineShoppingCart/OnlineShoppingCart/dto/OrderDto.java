package OnlineShoppingCart.OnlineShoppingCart.dto;


import OnlineShoppingCart.OnlineShoppingCart.entity.CartItem;
import OnlineShoppingCart.OnlineShoppingCart.entity.User;
import OnlineShoppingCart.OnlineShoppingCart.enums.OrderStatus;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import lombok.Data;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.util.Date;
import java.util.List;
import java.util.UUID;

@Data
public class OrderDto {
    private Long id;
    private String orderDescription;
    private Date date;
    private Long amount;
    private String address;
    private String payment;
    private OrderStatus orderStatus;
    private Long totalAmount;
    private Long discount;
    private UUID trackingId;
    private String couponName;



    private String userName;



    private List<CartItemsDto> cartItems;

}
