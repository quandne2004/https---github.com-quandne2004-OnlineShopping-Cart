package OnlineShoppingCart.OnlineShoppingCart.service.customer.wishlist;


import OnlineShoppingCart.OnlineShoppingCart.dto.ProductDto;
import OnlineShoppingCart.OnlineShoppingCart.dto.WishListDto;
import OnlineShoppingCart.OnlineShoppingCart.entity.Product;
import OnlineShoppingCart.OnlineShoppingCart.entity.User;
import OnlineShoppingCart.OnlineShoppingCart.entity.WishList;
import OnlineShoppingCart.OnlineShoppingCart.repository.ProductRepository;
import OnlineShoppingCart.OnlineShoppingCart.repository.UserRepository;
import OnlineShoppingCart.OnlineShoppingCart.repository.WishListRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class WishListServiceImpl implements WishListService{

    private final WishListRepository wishListRepository;
    private final ProductRepository productRepository;
    private final UserRepository userRepository;

    public WishListDto addProductToWishList(WishListDto wishListDto){
        Optional<Product> optionalProduct = productRepository.findById(wishListDto.getProductId());
        Optional<User> optionalUser = userRepository.findById(wishListDto.getUserId());

        if (optionalProduct.isPresent() && optionalUser.isPresent()){
            WishList wishList = new WishList();

            wishList.setProduct(optionalProduct.get());
            wishList.setUser(optionalUser.get());

            return wishListRepository.save(wishList).getWishListDto();
        }
        return null;
    }

    public List<WishListDto> getAllByUserId(Long userId){
        return wishListRepository.findAllByUserId(userId).stream().map(WishList::getWishListDto).collect(Collectors.toList());
    }
}
