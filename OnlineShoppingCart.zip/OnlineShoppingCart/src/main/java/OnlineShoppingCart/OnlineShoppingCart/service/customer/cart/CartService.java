package OnlineShoppingCart.OnlineShoppingCart.service.customer.cart;

import OnlineShoppingCart.OnlineShoppingCart.dto.AddProductInCartDto;
import OnlineShoppingCart.OnlineShoppingCart.dto.OrderDto;
import OnlineShoppingCart.OnlineShoppingCart.dto.PlaceOrderDto;
import org.springframework.http.ResponseEntity;

import java.util.List;
import java.util.UUID;

public interface CartService {
    ResponseEntity<?> addProductToCart(AddProductInCartDto addProductInCartDto);
    OrderDto getCardByUserId(Long userId);
    OrderDto applyCoupon(Long userId,String code);
    OrderDto increaseProduct(AddProductInCartDto addProductInCartDto);
    OrderDto decreaseProduct(AddProductInCartDto addProductInCartDto);
    OrderDto placeOrder(PlaceOrderDto placeOrderDto);
    List<OrderDto > getAllPlacedOrders(Long userId);
    OrderDto searchOrderByTrackingId(UUID trackingId);
}
