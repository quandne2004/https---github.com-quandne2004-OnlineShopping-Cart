package OnlineShoppingCart.OnlineShoppingCart.service.auth;

import OnlineShoppingCart.OnlineShoppingCart.dto.SignupRequest;
import OnlineShoppingCart.OnlineShoppingCart.dto.UserDto;

public interface AuthService {
    UserDto createUser(SignupRequest signupRequest);
    Boolean hasUserWithEmail(String email);
}
