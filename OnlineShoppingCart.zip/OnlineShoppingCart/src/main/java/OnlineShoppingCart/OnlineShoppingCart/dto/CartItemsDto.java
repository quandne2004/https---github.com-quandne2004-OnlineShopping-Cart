package OnlineShoppingCart.OnlineShoppingCart.dto;


import jakarta.persistence.Column;
import lombok.Data;

@Data
public class CartItemsDto {
    private Long id;
    private Long price;
    private Long quantity;
    @Column(name = "product_id")
    private Long productId;
    private Long orderId;
    private String productName;
    private byte[] returnedImg;
    private Long userId;
}
