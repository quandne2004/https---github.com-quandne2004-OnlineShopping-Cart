package OnlineShoppingCart.OnlineShoppingCart.dto;

import jakarta.persistence.Column;
import lombok.Data;

@Data
public class AddProductInCartDto {

    private Long userId;
    @Column(name = "product_id")
    private Long productId;
}
