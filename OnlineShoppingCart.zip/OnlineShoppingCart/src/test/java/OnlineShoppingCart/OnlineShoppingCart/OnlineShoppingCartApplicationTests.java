package OnlineShoppingCart.OnlineShoppingCart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineShoppingCartApplicationTests {

	@Test
	void contextLoads() {
	}

}
