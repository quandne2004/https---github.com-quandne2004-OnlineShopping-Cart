package OnlineShoppingCart.OnlineShoppingCart.controller.customer;


import OnlineShoppingCart.OnlineShoppingCart.dto.WishListDto;
import OnlineShoppingCart.OnlineShoppingCart.service.customer.wishlist.WishListService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/customer")
public class WishListController {

    private final WishListService wishListService;


    @PostMapping("/wishList")
    public ResponseEntity<?> addProductToWishList(@RequestBody WishListDto wishListDto){
        WishListDto wishListDto1 = wishListService.addProductToWishList(wishListDto);

        if (wishListDto == null){
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Error");
        }else {
            return ResponseEntity.status(HttpStatus.CREATED).body(wishListDto1);
        }

    }


    @GetMapping("/wishLists/{userId}")
    public ResponseEntity<List<WishListDto>> getWishListByUserId(@PathVariable Long userId){
        return ResponseEntity.ok(wishListService.getAllByUserId(userId));
    }
}
