package OnlineShoppingCart.OnlineShoppingCart.service.admin.coupon;


import OnlineShoppingCart.OnlineShoppingCart.entity.Coupon;
import OnlineShoppingCart.OnlineShoppingCart.exception.ValidationException;
import OnlineShoppingCart.OnlineShoppingCart.repository.CouponRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service

@RequiredArgsConstructor
public class CouponServiceImpl implements CouponService{

    private final CouponRepository couponRepository;


    public Coupon createCoupon(Coupon coupon){
        if (couponRepository.existsByCode(coupon.getCode())){
            throw new ValidationException("Coupon code already exists");
        }
        return couponRepository.save(coupon);
    }

    public List<Coupon> getAllCoupon(){
        return couponRepository.findAll();
    }
}
