package OnlineShoppingCart.OnlineShoppingCart.service.customer.review;


import OnlineShoppingCart.OnlineShoppingCart.dto.OrderedProductResponseDto;
import OnlineShoppingCart.OnlineShoppingCart.dto.ProductDto;
import OnlineShoppingCart.OnlineShoppingCart.dto.ReviewDto;
import OnlineShoppingCart.OnlineShoppingCart.entity.*;
import OnlineShoppingCart.OnlineShoppingCart.repository.OrderRepository;
import OnlineShoppingCart.OnlineShoppingCart.repository.ProductRepository;
import OnlineShoppingCart.OnlineShoppingCart.repository.ReviewRepository;
import OnlineShoppingCart.OnlineShoppingCart.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class ReviewServiceImpl implements ReviewService{

    private final OrderRepository orderRepository;

    private final ProductRepository productRepository;
    private final UserRepository userRepository;
    private final ReviewRepository reviewRepository;

    public OrderedProductResponseDto getOrderedProductsDetailsByOrderId(Long orderId){
        Optional<Order> optionalOrder = orderRepository.findById(orderId);
        OrderedProductResponseDto orderedProductResponseDto = new OrderedProductResponseDto();

        if (optionalOrder.isPresent()){
            orderedProductResponseDto.setOrderAmount(optionalOrder.get().getAmount());

            List<ProductDto> productDtoList = new ArrayList<>();
            for (CartItem cartItem :optionalOrder.get().getCartItems()){
                ProductDto productDto =new ProductDto();

                productDto.setId(cartItem.getProduct().getId());
                productDto.setName(cartItem.getProduct().getName());
                productDto.setPrice(cartItem.getPrice());
                productDto.setQuantity(cartItem.getQuantity());

                productDto.setByteImg(cartItem.getProduct().getImg());

                productDtoList.add(productDto);



            }

            orderedProductResponseDto.setProductDtoList(productDtoList);
        }

        return orderedProductResponseDto;
    }

    public ReviewDto giveReview(ReviewDto reviewDto) throws IOException {
        Optional<Product> optionalProduct = productRepository.findById(reviewDto.getProductId());

        Optional<User> optionalUser = userRepository.findById(reviewDto.getUserId());
        if (optionalUser.isPresent() && optionalProduct.isPresent()){
            Review review = new Review();

            review.setRating(reviewDto.getRating());
            review.setDescription(reviewDto.getDescription());
            review.setUser(optionalUser.get());
            review.setProduct(optionalProduct.get());
            review.setImg(reviewDto.getImg().getBytes());

            return reviewRepository.save(review).getReviewDto();
        }
        return null;
    }
}
