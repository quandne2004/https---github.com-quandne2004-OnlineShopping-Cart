package OnlineShoppingCart.OnlineShoppingCart.dto;

import OnlineShoppingCart.OnlineShoppingCart.enums.UserRole;
import lombok.Data;

import java.util.List;

@Data
public class UserDto {
    private Long id;
    private String name;
    private String email;
    private UserRole userRole;
    private List<CartItemsDto> cartItemsDtoList;
}
