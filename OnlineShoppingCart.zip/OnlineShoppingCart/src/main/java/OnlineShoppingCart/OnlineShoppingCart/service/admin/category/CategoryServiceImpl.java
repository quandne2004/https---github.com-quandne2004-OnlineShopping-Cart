package OnlineShoppingCart.OnlineShoppingCart.service.admin.category;


import OnlineShoppingCart.OnlineShoppingCart.dto.CategoryDto;
import OnlineShoppingCart.OnlineShoppingCart.entity.Category;
import OnlineShoppingCart.OnlineShoppingCart.repository.CategoryRepository;
import OnlineShoppingCart.OnlineShoppingCart.service.admin.category.CategoryService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class CategoryServiceImpl implements CategoryService {

    private final CategoryRepository categoryRepository;

    public Category createCategory(CategoryDto categoryDto){
        Category category = new Category();

        category.setName(categoryDto.getName());
        category.setDescription(categoryDto.getDescription());

        return categoryRepository.save(category);
    }

    public List<Category> getAllCategory(){
        return categoryRepository.findAll();
    }
}
