package OnlineShoppingCart.OnlineShoppingCart.dto;

import OnlineShoppingCart.OnlineShoppingCart.entity.Product;
import OnlineShoppingCart.OnlineShoppingCart.entity.User;
import jakarta.persistence.*;
import lombok.Data;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;
import org.springframework.web.multipart.MultipartFile;

@Data
public class ReviewDto {
    private Long id;

    private Long rating;


    @Lob
    private String description;


    private MultipartFile img;
    private byte[] returnedImg;



    private Long userId;

    private String username;


    private Long productId;
}
