package OnlineShoppingCart.OnlineShoppingCart.service.admin.category;

import OnlineShoppingCart.OnlineShoppingCart.dto.CategoryDto;
import OnlineShoppingCart.OnlineShoppingCart.entity.Category;

import java.util.List;

public interface CategoryService {
    Category createCategory(CategoryDto categoryDto);
    List<Category> getAllCategory();
}
